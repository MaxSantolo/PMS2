create view v_continuity as
  select
    `crm_punti`.`esolver_invoices`.`id`                                        AS `id`,
    `crm_punti`.`esolver_invoices`.`CodFiscale`                                AS `codfiscale`,
    `crm_punti`.`esolver_invoices`.`DataFatturaDa`                             AS `first_invoice`,
    round(((to_days(`crm_punti`.`esolver_invoices`.`DataFatturaA`) -
            to_days(`crm_punti`.`esolver_invoices`.`DataFatturaDa`)) / 30), 0) AS `months`,
    `crm_punti`.`esolver_invoices_importstatus`.`date`                         AS `invoicedate`,
    `crm_punti`.`esolver_invoices_importstatus`.`status`                       AS `invoice_status`,
    `crm_punti`.`users`.`active`                                               AS `active`,
    `crm_punti`.`users`.`status`                                               AS `user_status`
  from ((`crm_punti`.`esolver_invoices`
    left join `crm_punti`.`esolver_invoices_importstatus`
      on ((`crm_punti`.`esolver_invoices`.`id` = `crm_punti`.`esolver_invoices_importstatus`.`id`))) join
    `crm_punti`.`users` on ((`crm_punti`.`users`.`codfiscale` = `crm_punti`.`esolver_invoices`.`CodFiscale`)))
  having (
    (`invoice_status` not in ('RECEIPT', 'imported', 'MANUAL', 'ZERO')) and (`user_status` not in ('nocf', 'nomail'))
    and (`crm_punti`.`users`.`active` = 1));

