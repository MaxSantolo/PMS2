create view v_invoices as
  select
    `crm_punti`.`esolver_invoices`.`id`                                                             AS `invoice_id`,
    `crm_punti`.`esolver_invoices_importstatus`.`id`                                                AS `invoice_status_id`,
    `crm_punti`.`esolver_invoices`.`DataFatturaDa`                                                  AS `DataFatturaDa`,
    `crm_punti`.`esolver_invoices`.`DataFatturaA`                                                   AS `DataFatturaA`,
    `crm_punti`.`esolver_invoices`.`ImportoValuta`                                                  AS `imponibile`,
    `crm_punti`.`esolver_invoices`.`DesEstesa`                                                      AS `DesEstesa`,
    `crm_punti`.`esolver_invoices`.`PartitaIva`                                                     AS `PartitaIva`,
    `crm_punti`.`esolver_invoices`.`CodFiscale`                                                     AS `CodFiscale`,
    concat(`crm_punti`.`esolver_invoices`.`RagSoc1`, ' ', `crm_punti`.`esolver_invoices`.`RagSoc2`) AS `company`,
    `crm_punti`.`esolver_invoices_importstatus`.`date`                                              AS `importdate`,
    `crm_punti`.`esolver_invoices_importstatus`.`status`                                            AS `invoice_status`,
    round(((to_days(`crm_punti`.`esolver_invoices`.`DataFatturaA`) -
            to_days(`crm_punti`.`esolver_invoices`.`DataFatturaDa`)) / 30), 0)                      AS `months`,
    `crm_punti`.`credits`.`id`                                                                      AS `creditid`,
    `crm_punti`.`credits`.`bookid`                                                                  AS `bookid`,
    `crm_punti`.`credits`.`date`                                                                    AS `credits_date`,
    `crm_punti`.`credits`.`points`                                                                  AS `points`,
    `crm_punti`.`credits`.`origin`                                                                  AS `origin`,
    `crm_punti`.`credits`.`status`                                                                  AS `status`
  from ((`crm_punti`.`esolver_invoices`
    left join `crm_punti`.`esolver_invoices_importstatus`
      on ((`crm_punti`.`esolver_invoices`.`id` = `crm_punti`.`esolver_invoices_importstatus`.`id`))) left join
    `crm_punti`.`credits` on ((`crm_punti`.`credits`.`invoiceid` = `crm_punti`.`esolver_invoices`.`id`)));

