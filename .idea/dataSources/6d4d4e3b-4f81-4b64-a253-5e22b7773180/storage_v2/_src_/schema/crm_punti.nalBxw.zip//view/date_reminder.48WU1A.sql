create view date_reminder as
  select
    `crm_punti`.`anagrafica_punti`.`nome`                             AS `nome`,
    `crm_punti`.`anagrafica_punti`.`email`                            AS `email`,
    `crm_punti`.`anagrafica_punti`.`id_cliente_booking`               AS `id_cliente_booking`,
    min(`crm_punti`.`accrediti`.`data_accredito`)                     AS `primo_accredito`,
    (min(`crm_punti`.`accrediti`.`data_accredito`) + interval 30 day) AS `data_reminder`
  from (`crm_punti`.`accrediti`
    join `crm_punti`.`anagrafica_punti`)
  where ((`crm_punti`.`accrediti`.`accreditato` = 'In attesa') and
         (`crm_punti`.`accrediti`.`id_cliente` = `crm_punti`.`anagrafica_punti`.`id`))
  group by `crm_punti`.`accrediti`.`id_cliente`;

