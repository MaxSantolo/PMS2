create view v_general_options as
  select
    `crm_punti`.`credits_schema`.`id`      AS `id`,
    `crm_punti`.`credits_schema`.`restype` AS `restype`,
    `crm_punti`.`credits_schema`.`metakey` AS `metakey`,
    `crm_punti`.`credits_schema`.`value`   AS `value`
  from `crm_punti`.`credits_schema`
  where ((not ((`crm_punti`.`credits_schema`.`metakey` like '%condiz%'))) and
         (not ((`crm_punti`.`credits_schema`.`metakey` like '%Promo%'))))
  order by `crm_punti`.`credits_schema`.`restype`;

