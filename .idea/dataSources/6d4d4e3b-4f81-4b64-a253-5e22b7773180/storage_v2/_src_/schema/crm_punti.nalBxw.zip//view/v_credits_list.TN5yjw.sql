create view v_credits_list as select
                                `crm_punti`.`credits`.`id`        AS `id`,
                                `crm_punti`.`credits`.`bookid`    AS `bookid`,
                                `crm_punti`.`credits`.`date`      AS `date`,
                                `crm_punti`.`credits`.`points`    AS `points`,
                                `crm_punti`.`credits`.`origin`    AS `origin`,
                                `crm_punti`.`credits`.`status`    AS `status`,
                                `crm_punti`.`credits`.`note`      AS `note`,
                                `crm_punti`.`users`.`company`     AS `company`,
                                `crm_punti`.`users`.`bookingmail` AS `bookingmail`,
                                `crm_punti`.`users`.`crmemail`    AS `crmemail`,
                                `crm_punti`.`users`.`codfiscale`  AS `codfiscale`,
                                `crm_punti`.`users`.`partitaiva`  AS `partitaiva`
                              from ((`crm_punti`.`credits`
                                join `crm_punti`.`esolver_invoices`
                                  on ((`crm_punti`.`credits`.`invoiceid` = `crm_punti`.`esolver_invoices`.`id`))) join
                                `crm_punti`.`users`
                                  on ((`crm_punti`.`users`.`codfiscale` = `crm_punti`.`esolver_invoices`.`CodFiscale`)))
                              union all select
                                          `crm_punti`.`credits`.`id`        AS `id`,
                                          `crm_punti`.`credits`.`bookid`    AS `bookid`,
                                          `crm_punti`.`credits`.`date`      AS `date`,
                                          `crm_punti`.`credits`.`points`    AS `points`,
                                          `crm_punti`.`credits`.`origin`    AS `origin`,
                                          `crm_punti`.`credits`.`status`    AS `status`,
                                          `crm_punti`.`credits`.`note`      AS `note`,
                                          `crm_punti`.`users`.`company`     AS `company`,
                                          `crm_punti`.`users`.`bookingmail` AS `bookingmail`,
                                          `crm_punti`.`users`.`crmemail`    AS `crmemail`,
                                          `crm_punti`.`users`.`codfiscale`  AS `codicefiscale`,
                                          `crm_punti`.`users`.`partitaiva`  AS `partitaiva`
                                        from (`crm_punti`.`credits`
                                          join `crm_punti`.`users`
                                            on ((`crm_punti`.`users`.`bookid` = `crm_punti`.`credits`.`bookid`)))
                                        where (`crm_punti`.`credits`.`origin` in
                                               ('ANNIVERSARY', 'BIRTHDAY', 'BONUS', 'RENEWAL', 'CORRECTION'));

