create view v_credits as
  select
    `crm_punti`.`credits`.`id`        AS `id`,
    `crm_punti`.`users`.`bookid`      AS `bookid`,
    `crm_punti`.`credits`.`points`    AS `points`,
    `crm_punti`.`credits`.`date`      AS `date`,
    `crm_punti`.`credits`.`status`    AS `status`,
    `crm_punti`.`users`.`company`     AS `company`,
    `crm_punti`.`users`.`bookingmail` AS `bookingmail`,
    `crm_punti`.`users`.`crmemail`    AS `crmemail`,
    `crm_punti`.`credits`.`origin`    AS `origin`,
    `crm_punti`.`users`.`codfiscale`  AS `codfiscale`,
    `crm_punti`.`users`.`partitaiva`  AS `partitaiva`
  from ((`crm_punti`.`credits`
    left join `crm_punti`.`esolver_invoices`
      on ((`crm_punti`.`esolver_invoices`.`id` = `crm_punti`.`credits`.`invoiceid`))) left join `crm_punti`.`users`
      on ((`crm_punti`.`esolver_invoices`.`CodFiscale` = `crm_punti`.`users`.`codfiscale`)))
  where ((`crm_punti`.`credits`.`status` not in ('zero', 'credited', 'sentlost')) and
         (`crm_punti`.`users`.`codfiscale` <> ''));

