create view v_receipts as
  select
    `v_invoices`.`invoice_id`                                           AS `invoice_id`,
    `v_invoices`.`invoice_status_id`                                    AS `invoice_status_id`,
    `v_invoices`.`DataFatturaDa`                                        AS `DataFatturaDa`,
    `v_invoices`.`DataFatturaA`                                         AS `DataFatturaA`,
    `v_invoices`.`imponibile`                                           AS `imponibile`,
    `v_invoices`.`DesEstesa`                                            AS `DesEstesa`,
    `v_invoices`.`PartitaIva`                                           AS `PartitaIva`,
    `v_invoices`.`CodFiscale`                                           AS `CodFiscale`,
    `v_invoices`.`company`                                              AS `company`,
    `v_invoices`.`importdate`                                           AS `importdate`,
    `v_invoices`.`invoice_status`                                       AS `invoice_status`,
    `v_invoices`.`months`                                               AS `months`,
    `v_invoices`.`creditid`                                             AS `creditid`,
    `v_invoices`.`bookid`                                               AS `bookid`,
    `v_invoices`.`credits_date`                                         AS `credits_date`,
    `v_invoices`.`points`                                               AS `points`,
    `v_invoices`.`origin`                                               AS `origin`,
    `v_invoices`.`status`                                               AS `status`,
    `crm_punti`.`users`.`bookid`                                        AS `usrbookid`,
    floor(((`v_invoices`.`imponibile` * 3) / 1000))                     AS `discountable`,
    cast(round((`v_invoices`.`imponibile` / 100), 2) as decimal(10, 2)) AS `value`
  from (`crm_punti`.`v_invoices`
    left join `crm_punti`.`users` on ((`v_invoices`.`CodFiscale` = `crm_punti`.`users`.`codfiscale`)))
  where ((`v_invoices`.`invoice_status` = 'receipt') and (
    (`v_invoices`.`DesEstesa` like '%Sal%') or (`v_invoices`.`DesEstesa` like '%Ufficio%') or
    (`v_invoices`.`DesEstesa` like '%desk%') or (`v_invoices`.`DesEstesa` like '%office%') or
    (`v_invoices`.`DesEstesa` like '%eventi%') or (`v_invoices`.`DesEstesa` like '%telef%') or
    (`v_invoices`.`DesEstesa` like '%messagg%') or (`v_invoices`.`DesEstesa` like '%segreteria%') or
    (`v_invoices`.`DesEstesa` like '%fattorino%') or (`v_invoices`.`DesEstesa` like '%assist%') or
    (`v_invoices`.`DesEstesa` like '%prenot%') or (`v_invoices`.`DesEstesa` like '%video%') or
    (`v_invoices`.`DesEstesa` like '%lavagn%') or (`v_invoices`.`DesEstesa` like '%tv%') or
    (`v_invoices`.`DesEstesa` like '%pc%')) and (`crm_punti`.`users`.`bookid` <> 0) and
         (floor(((`v_invoices`.`imponibile` * 3) / 1000)) <> 0));

