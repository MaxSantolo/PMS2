create view v_promo_options as
  select
    `crm_punti`.`credits_schema`.`id`      AS `id`,
    `crm_punti`.`credits_schema`.`restype` AS `restype`,
    `crm_punti`.`credits_schema`.`metakey` AS `metakey`,
    `crm_punti`.`credits_schema`.`value`   AS `value`
  from `crm_punti`.`credits_schema`
  where (`crm_punti`.`credits_schema`.`metakey` like '%Promo%')
  order by `crm_punti`.`credits_schema`.`restype`, `crm_punti`.`credits_schema`.`metakey` desc;

