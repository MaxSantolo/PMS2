create view v_charges as
  select
    `crm_punti`.`charges`.`id`          AS `id`,
    `crm_punti`.`charges`.`number`      AS `number`,
    `crm_punti`.`charges`.`center`      AS `center`,
    `crm_punti`.`charges`.`category`    AS `category`,
    `crm_punti`.`charges`.`source`      AS `source`,
    `crm_punti`.`charges`.`dom2userid`  AS `dom2userid`,
    `crm_punti`.`charges`.`datestart`   AS `datestart`,
    `crm_punti`.`charges`.`dateend`     AS `dateend`,
    `crm_punti`.`charges`.`value`       AS `value`,
    `crm_punti`.`charges`.`partitaiva`  AS `partitaiva`,
    `crm_punti`.`charges`.`codfiscale`  AS `codfiscale`,
    `crm_punti`.`charges`.`description` AS `description`,
    `crm_punti`.`charges`.`deleted`     AS `deleted`,
    `crm_punti`.`users`.`company`       AS `company`,
    `crm_punti`.`users`.`bookingmail`   AS `bookingmail`,
    `crm_punti`.`users`.`bookid`        AS `bookid`,
    `crm_punti`.`users`.`crmid`         AS `crmid`,
    `crm_punti`.`users`.`crmtype`       AS `crmtype`
  from (`crm_punti`.`charges`
    left join `crm_punti`.`users` on ((`crm_punti`.`charges`.`codfiscale` = `crm_punti`.`users`.`codfiscale`)))
  where ((`crm_punti`.`users`.`bookid` <> 0) and (`crm_punti`.`users`.`status` = 'active'))
  order by `crm_punti`.`users`.`company`;

