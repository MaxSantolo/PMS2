create view v_where_options as
  select
    `crm_punti`.`credits_schema`.`id`      AS `id`,
    `crm_punti`.`credits_schema`.`restype` AS `restype`,
    `crm_punti`.`credits_schema`.`metakey` AS `metakey`,
    `crm_punti`.`credits_schema`.`value`   AS `value`
  from `crm_punti`.`credits_schema`
  where (`crm_punti`.`credits_schema`.`metakey` like '%condizioni%')
  order by `crm_punti`.`credits_schema`.`restype` desc;

